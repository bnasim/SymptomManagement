package org.magnum.mobilecloud.video;

import java.io.IOException;
import java.security.Principal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import javassist.NotFoundException;

import org.magnum.mobilecloud.video.client.VideoSvcApi;
import org.magnum.mobilecloud.video.repository.Video;
import org.magnum.mobilecloud.video.repository.VideoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;

@Controller
public class MyController {
	
	public static final String ID_PARAMETER = "id"; 
	@Autowired
	private VideoRepository videos;
	
	/**
	 * You will need to create one or more Spring controllers to fulfill the
	 * requirements of the assignment. If you use this file, please rename it
	 * to something other than "AnEmptyController"
	 * 
	 * 
		 ________  ________  ________  ________          ___       ___  ___  ________  ___  __       
		|\   ____\|\   __  \|\   __  \|\   ___ \        |\  \     |\  \|\  \|\   ____\|\  \|\  \     
		\ \  \___|\ \  \|\  \ \  \|\  \ \  \_|\ \       \ \  \    \ \  \\\  \ \  \___|\ \  \/  /|_   
		 \ \  \  __\ \  \\\  \ \  \\\  \ \  \ \\ \       \ \  \    \ \  \\\  \ \  \    \ \   ___  \  
		  \ \  \|\  \ \  \\\  \ \  \\\  \ \  \_\\ \       \ \  \____\ \  \\\  \ \  \____\ \  \\ \  \ 
		   \ \_______\ \_______\ \_______\ \_______\       \ \_______\ \_______\ \_______\ \__\\ \__\
		    \|_______|\|_______|\|_______|\|_______|        \|_______|\|_______|\|_______|\|__| \|__|
                                                                                                                                                                                                                                                                        
	 * 
	 */
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.POST)
	public @ResponseBody Video addVideo(@RequestBody Video v){
	v.setLikes(0);
	videos.save(v);
	return v;
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> getVideoList(){
	return Lists.newArrayList(videos.findAll());
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<Video> getVideoById(@PathVariable(ID_PARAMETER) long id){
		Video v = videos.findOne(id);
		if (v == null) {
			return new ResponseEntity<Video>(v,HttpStatus.NOT_FOUND);
		}
		else
			return new ResponseEntity<Video>(v,HttpStatus.OK);
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_TITLE_SEARCH_PATH, method=RequestMethod.GET)
	public @ResponseBody Collection<Video> findByTitle(
	// Tell Spring to use the "title" parameter in the HTTP request's query
	// string as the value for the title method parameter
	@RequestParam(VideoSvcApi.TITLE_PARAMETER) String title
	){
	return videos.findByName(title);
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_DURATION_SEARCH_PATH, method = RequestMethod.GET)
	public @ResponseBody Collection<Video> findByDurationLessThan(@RequestParam(VideoSvcApi.DURATION_PARAMETER) long duration) {
		return videos.findByDurationLessThan(duration);
	}
	
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/like", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Void> likeVideo(@PathVariable("id") long id, Principal p,HttpServletResponse response) {
		Video v = videos.findOne(id);
		if (v == null) {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		String username = p.getName(); 
		Set<String> likedUsers = v.getLikesUsernames(); 
		if (likedUsers.contains(username)) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		likedUsers.add(username);
		v.setLikesUsernames(likedUsers);
		v.setLikes(likedUsers.size());
		videos.save(v);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	@RequestMapping(value = VideoSvcApi.VIDEO_SVC_PATH + "/{id}/unlike", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<Void> unlikeVideo(@PathVariable("id") long id, Principal p,HttpServletResponse response) {
		Video v = videos.findOne(id);
		if (v == null) {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		String username = p.getName(); 
		Set likedUsers = v.getLikesUsernames(); 
		if (!likedUsers.contains(username)) {
			return new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
		}
		likedUsers.remove(username);
		v.setLikesUsernames(likedUsers);
		v.setLikes(likedUsers.size());
		videos.save(v);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	@RequestMapping(value=VideoSvcApi.VIDEO_SVC_PATH + "/{id}/likedby", method=RequestMethod.GET)
    public @ResponseBody Collection<String> getUsersWhoLikedVideo(@PathVariable("id") long id, HttpServletResponse response)
{
		Video v = videos.findOne(id);
		if (v == null) {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
			return null;
		}
		else
        response.setStatus(HttpServletResponse.SC_OK);
        return  v.getLikesUsernames();
}
}

